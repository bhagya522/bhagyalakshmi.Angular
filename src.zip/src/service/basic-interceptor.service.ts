import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
//this give you opportunity to carry out common functionality for all http outgoing request
//for eg., passing credentials through headers while accessing secured rest endpoints
//this is mandatory to make entry of this class in app.module.ts file
export class BasicInterceptorService implements HttpInterceptor {

  constructor() { }
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    console.log("in basicInterceptor");
    let basicRequest=req.clone({
      setHeaders:{Authorization:'Basic '+btoa('zensar:zensar')}
    })
    return next.handle(basicRequest);
  }
}
