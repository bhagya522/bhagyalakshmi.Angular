import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthguardService implements CanActivate {

  constructor(private router:Router) { }
  canActivate(): boolean {
    //calling method can be used to check if any specific roots allow to access or not
    //if can active method true it allows to access the routes
    //if return false not allowed 
    console.log("in AuthGuardService")
    if(false){
      this.router.navigate(['login'])
      return false;
    }
    return true;
  }
}
