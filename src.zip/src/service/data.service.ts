import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable, of } from "rxjs";
import { environment } from "src/environments/environment";
import { Message } from "src/model/Message";

@Injectable({
  providedIn: "root",
})
export class DataService {
  private messages: Message[] = [];

  constructor(private http:HttpClient) {

    //todo fetch all this message object from backend rest end point 

    // let message1 = new Message(101, "Morning");
    // let message2 = new Message(102, "Afternoon");
    // let message3 = new Message(103, "Evening");
    // let message4 = new Message(103, "Night");

    // this.messages.push(message1);
    // this.messages.push(message2);
    // this.messages.push(message3);
    // this.messages.push(message4);
  }


  addMessage(message:Message){

    let h=new HttpHeaders().append("Authorization","Basic " + btoa("zensar:zensar"));
    return this.http.post<Message>(environment.url+'/api/message/add',message,{headers:h});

  }
  getMessages(){

    let h=new HttpHeaders().append("Authorization","Basic " + btoa("zensar:zensar"));
    return this.http.get<Message[]>(environment.url+'/api/message',{headers:h});
  }

  deleteMessageById(id:number){
    let h=new HttpHeaders().append("Authorization","Basic " + btoa("zensar:zensar"));
    return this.http.delete(environment.url+'/api/message/'+id,{headers:h});
  }

  updateMessage(message: Message){
    let h=new HttpHeaders().append("Authorization","Basic " + btoa("zensar:zensar"));
    return this.http.put<Message>(environment.url+'/api/message/update',message,{headers:h});
  }

  getMesssagesWithObservales(): Observable<Message[]> {
    return of(this.messages);
  }
  
}
