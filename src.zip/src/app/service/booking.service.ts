import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BookingService {

  booking =[{
    "roomNo":"106",
    "charges":"200.00"
  },{
    "roomNo":"107",
    "charges":"300.00"
  },
  {
    "roomNo":"108",
    "charges":"800.00"
  }

]

  constructor() { }

 getAllRoomsForBooking(){
   return this.booking;
 }
 bookRoom():string{
   alert("Booking Success")
   return "Booking Success";
 }
}
