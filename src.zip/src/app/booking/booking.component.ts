import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BookingService } from '../service/booking.service';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {
  allRoomsForBooking=[];
  constructor(private service:BookingService, private router: Router) { 
    this.allRoomsForBooking=this.service.getAllRoomsForBooking();
  }
  book(){
    this.services.bookRoom();
  }

  ngOnInit() {
  }

}
