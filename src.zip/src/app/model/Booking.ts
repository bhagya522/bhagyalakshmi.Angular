import { Room } from "./Room";
import { User } from "./User";

export class Booking{
  public id: number; 
  public room: Room; 
  public user: User; 
  public purpose: string; 
  public participants: number;
  
  constructor(id=0,room={},user={},purpose="",participants=0){
    

  }
}