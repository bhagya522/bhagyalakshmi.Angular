export class User{

  public id: number; 
  public email : string; 
  public password: string;

  constructor(id=0,email="", password=""){
  }
}