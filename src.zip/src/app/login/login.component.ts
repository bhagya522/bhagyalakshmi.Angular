import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../model/User';
import { LoginService } from '../service/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user:User=new User(); 
  constructor(private service:LoginService, private router: Router) { }

  ngOnInit() {
  }

  
  performLogin(){
    let res=this.service.checkUser(this.user);
    //if true navigate other component
    if(true)
     {
       this.router.navigate(['booking'])
     }
     else{
       alert("Invalid Username/Password")
       //this.router.navigate(['login'])
     }
   }


}
