import { nullSafeIsEquivalent } from '@angular/compiler/src/output/output_ast';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Message } from 'src/model/Message';
import { DataService } from 'src/service/data.service';

@Component({
  selector: 'app-message-update',
  templateUrl: './message-update.component.html',
  styleUrls: ['./message-update.component.css']
})
export class MessageUpdateComponent implements OnInit {

  

  //@Input => communication from parent to child i.e.child is accepting input from parent.
  @Input()
  childMsg:Message=new Message(0,"");

  //send the data from child to parent
  //EventEmitter is used to emit events so that data of specified type from @angular/core
  //can be passed to parent component
  //it is specified using generix
  @Output()
  updatedMessage:EventEmitter<Message>=new EventEmitter<Message>();

  performUpdate(){
    console.log("Message after updating: ");
    // console.log(this.childMsg.id);
    // console.log(this.childMsg.name);

    //events are emitted using emit() method of event listner
    //while emitting event we can pass the data in emit method
    this.updatedMessage.emit(this.childMsg);
    this.service.updateMessage(new Message(this.childMsg.id,this.childMsg.name)).subscribe(success=>console.log(success))
  }

  constructor(private service:DataService) { }

  ngOnInit() {
  }

}
